<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use Illuminate\Http\Request;

class ContactController extends Controller
{
    public function store(Request $request)
    {
        $request->validate([
            'email' => "required | email",
            'question' => "required | string",
            'message' => "required | string",
            'code' => "required | string",
        ]);

        return Contact::create([
            'email' => $request->email,
            'question' => $request->question,
            'message' => $request->message,
            'code' => $request->code,
            "condition" => false
        ]);
    }
}
