<?php
return [
    'home'=>[
        'close'=>'إغلاق',
        'show-all'=>'عرض الكل',
    ]
];