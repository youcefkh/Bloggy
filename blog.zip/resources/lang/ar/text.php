<?php
return [
   'home'=>[
       'a-question-?'=>'سؤال ؟',
       'result-search'=>'نتيجة البحث :'
   ]
];