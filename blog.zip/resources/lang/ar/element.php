<?php
return [
  'navbar'=> array(
      'home'=>'الرئيسية',
      'about-us'=>'حولنا',
      'privacy'=>'سياسة الخصوصية',
      'terms'=>'شروط الاستعمال'
  )
];