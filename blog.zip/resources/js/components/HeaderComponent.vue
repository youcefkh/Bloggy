<template>
    <header class="banner" role="banner">
        <nav
            class="nav-skip"
            role="navigation"
            aria-label="Liens d&#39;évitement"
            lang="fr"
        >
            <div class="container">
                <ul id="top">
                    <li data-test="skip-link-content">
                        <a href="#main">Aller au contenu</a>
                    </li>
                    <li data-test="skip-link-search">
                        <a href="#search">Aller à la recherche</a>
                    </li>
                    <li data-test="skip-link-navmain" class="skip-link-nav">
                        <a href="#nav-main">Aller au menu de Particuliers</a>
                    </li>
                </ul>
            </div>
        </nav>
        <div
            class="nav-top"
            data-_csrf="d00bd08a-db89-4082-8c70-9c3138d26ce4"
            data-_csrf_header="X-CSRF-TOKEN"
        >
            <div class="container">
                <nav
                    class="nav-top-main"
                    role="navigation"
                    aria-label="menu principal"
                >
                    <ul>
                        <li class="nav-top-menu">
                            <button
                                id="nav-open-btn"
                                aria-controls="nav-mobile"
                                aria-expanded="false"
                                class="btn btn-menu nav-top-menu"
                                type="button"
                            >
                                menu
                            </button>
                        </li>
                    </ul>
                </nav>
            </div>
        </div>

        <div id="account-access-disable" class="nav-compte collapse">
            <div class="container">
                <p class="close">
                    <button
                        class="btn btn-link btn-close"
                        data-toggle="collapse"
                        data-target="#account-access-disable"
                        title="Fermer la fenêtre de connexion à Mon compte"
                    >
                        Fermer
                    </button>
                </p>
                <div class="row compte-login compte-login-fc">
                    <div class="alert alert-bloc alert-info">
                        <p>
                            L’accès au compte est temporairement désactivé pour
                            maintenance.
                        </p>
                        <p>
                            Veuillez nous excuser pour ce désagrement. Essayez
                            ultérieurement.
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container container-logo">
            <div class="logo">
                <img
                    data-test="img-non-deuil"
                    class="img-marianne"
                    src="https://www.service-public.fr/resources/v-a0de4bc5fc/web/img/republique-francaise.png"
                    alt="République Française"
                    width="150"
                    height="130"
                />
                <a
                    href="https://www.service-public.fr/"
                    data-xiti-name="Logo::Particuliers::Accueil::Accueil"
                >
                    <img
                        class="img-sce-public"
                        src="https://www.service-public.fr/resources/v-a0de4bc5fc/web/img/service-public.png"
                        alt="Accueil Service-Public.fr"
                        width="250"
                        height="130"
                    />
                </a>
            </div>
            <div class="nav-header">
                <ul>
                    <li class="nav-header-1">
                        <router-link :to="{name: 'contact'}">
                            <svg
                                focusable="false"
                                width="35"
                                height="35"
                                class="icon-question"
                                aria-hidden="true"
                            >
                                <use xlink:href="#icon-question"></use>
                            </svg>
                            {{$t('question')}}
                        </router-link>
                    </li>
                </ul>
            </div>
        </div>
        <!-- <nav
            class="nav-mobile"
            id="nav-mobile"
            role="navigation"
            aria-label="menu Particuliers (affichage mobile)"
        >
            <p class="nav-mobile-close">
                <button
                    id="nav-close-btn"
                    class="btn btn-close"
                    type="button"
                    title="Fermer le menu Particuliers"
                >
                    Fermer
                </button>
            </p>
            <div class="nav-mobile-espace">
                <p><a>Category 1 Only (Limit 10)</a></p>
                <ul>
                    <li><a href="#">Article 1</a></li>
                    <li><a href="#">Article 2</a></li>
                    <li><a href="#">Article 3</a></li>
                    <li><a href="#">Article 4</a></li>
                </ul>
            </div>
        </nav> -->
    </header>
</template>

<script>
export default {
    mounted() {
        console.log("header component");
    },
};
</script>

<style scoped>
.container.container-logo {
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.container:before, .container:after {
    content: " ";
    display: none;
}
.nav-header li a {
    width: max-content;
}
</style>
