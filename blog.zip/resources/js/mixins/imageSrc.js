export default{
    methods: {
        getArticleImg(img){
            return "/" + img;
        },
        getCatImg(img){
            return "/" + img;
        },
    },
} 